import React, { createContext, useContext, useState, useEffect } from "react";
import type { Language } from "../i18n";

export type Theme = "dark" | "light";
export type NavTab = "explore" | "nearby" | "doctors" | "ai" | "profile";

interface AppContextType {
  theme: Theme;
  toggleTheme: () => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  cartCount: number;
  setCartCount: (n: number) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>("dark");
  const [language, setLanguage] = useState<Language>("en");
  const [activeTab, setActiveTab] = useState<NavTab>("explore");
  const [cartCount, setCartCount] = useState(0);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
  }, [theme]);

  const toggleTheme = () => setTheme((t) => (t === "dark" ? "light" : "dark"));

  return (
    <AppContext.Provider
      value={{ theme, toggleTheme, language, setLanguage, activeTab, setActiveTab, cartCount, setCartCount }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
