import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { Toaster } from "sonner";
import { AppProvider, useApp } from "./context/AppContext";
import SplashScreen from "./components/SplashScreen";
import Header from "./components/Header";
import BottomNav from "./components/BottomNav";
import ExploreScreen from "./screens/ExploreScreen";
import NearbyScreen from "./screens/NearbyScreen";
import DoctorsScreen from "./screens/DoctorsScreen";
import AIScreen from "./screens/AIScreen";
import ProfileScreen from "./screens/ProfileScreen";
import { useState } from "react";

export default function App() {
  return (
    <AppProvider>
      <AppInner />
      <Toaster />
    </AppProvider>
  );
}

function AppInner() {
  const [splashDone, setSplashDone] = useState(false);
  const { theme } = useApp();

  if (!splashDone) {
    return <SplashScreen onDone={() => setSplashDone(true)} />;
  }

  return (
    <div className={theme === "dark" ? "dark" : ""}>
      <Unauthenticated>
        <AuthScreen />
      </Unauthenticated>
      <Authenticated>
        <MainApp />
      </Authenticated>
    </div>
  );
}

function AuthScreen() {
  const { theme } = useApp();
  const isDark = theme === "dark";

  return (
    <div className={`min-h-screen flex flex-col ${isDark ? "bg-raey-darker" : "bg-gray-50"}`}>
      {/* Hero */}
      <div className="bg-gradient-to-br from-primary via-teal-500 to-blue-600 px-6 pt-16 pb-12 relative overflow-hidden">
        <div className="absolute inset-0 shimmer" />
        <div className="absolute top-0 right-0 w-40 h-40 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-32 h-32 rounded-full bg-teal-300/20 blur-2xl" />
        <div className="relative z-10 flex flex-col items-center gap-4">
          <div className="w-24 h-24 rounded-3xl bg-white/20 flex items-center justify-center animate-float glow-green">
            <span className="text-5xl">💊</span>
          </div>
          <div className="text-center">
            <h1 className="text-5xl font-black text-white glow-text-green">ራዕይ</h1>
            <p className="text-xl font-bold text-white/90 mt-1 tracking-widest">Ra'ey</p>
            <p className="text-white/70 text-sm mt-2">Ethiopia's #1 Medicine Delivery</p>
          </div>
          <div className="flex gap-4 mt-2">
            {["🇪🇹 Ethiopian", "🔒 Secure", "⚡ Fast"].map((tag) => (
              <span key={tag} className="text-white/80 text-xs font-semibold bg-white/10 px-3 py-1 rounded-full">{tag}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Sign in form */}
      <div className="flex-1 px-6 py-8">
        <div className={`rounded-3xl p-6 ${isDark ? "bg-raey-card border border-raey-border" : "bg-white shadow-card"}`}>
          <h2 className={`text-xl font-black mb-6 text-center ${isDark ? "text-white" : "text-gray-900"}`}>
            Sign in to Ra'ey
          </h2>
          <SignInForm />
        </div>
        <p className={`text-center text-xs mt-6 ${isDark ? "text-white/30" : "text-gray-400"}`}>
          🇪🇹 Made with ❤️ for Ethiopia by Mikiyas Teshome
        </p>
      </div>
    </div>
  );
}

function MainApp() {
  const { activeTab, theme } = useApp();
  const isDark = theme === "dark";

  return (
    <div className={`min-h-screen ${isDark ? "bg-raey-darker" : "bg-gray-50"}`}>
      <Header />
      <main>
        {activeTab === "explore" && <ExploreScreen />}
        {activeTab === "nearby" && <NearbyScreen />}
        {activeTab === "doctors" && <DoctorsScreen />}
        {activeTab === "ai" && <AIScreen />}
        {activeTab === "profile" && <ProfileScreen />}
      </main>
      <BottomNav />
    </div>
  );
}
