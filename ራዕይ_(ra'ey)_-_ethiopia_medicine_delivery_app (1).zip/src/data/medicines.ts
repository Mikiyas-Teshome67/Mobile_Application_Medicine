export interface Medicine {
  id: string;
  nameEn: string;
  nameAm: string;
  nameOr: string;
  descEn: string;
  descAm: string;
  descOr: string;
  category: string;
  price: number;
  image: string;
  manufacturer: string;
  dosageEn: string;
  dosageAm: string;
  sideEffectsEn: string;
  sideEffectsAm: string;
  requiresPrescription: boolean;
  inStock: boolean;
  rating: number;
  reviews: number;
  emoji: string;
  color: string;
}

export interface Provider {
  id: string;
  name: string;
  address: string;
  distance: number;
  rating: number;
  isOpen: boolean;
  phone: string;
  email: string;
  telegram: string;
  github: string;
  youtube: string;
  lat: number;
  lng: number;
  specialties: string[];
  color: string;
}

export const medicines: Medicine[] = [
  {
    id: "1",
    nameEn: "Amoxicillin 500mg",
    nameAm: "አሞክሲሲሊን 500mg",
    nameOr: "Amoxicillin 500mg",
    descEn: "Broad-spectrum antibiotic used to treat bacterial infections including respiratory tract, urinary tract, and skin infections.",
    descAm: "የባክቴሪያ ኢንፌክሽኖችን ለማከም የሚያገለግል ሰፊ-ስፔክትረም አንቲባዮቲክ።",
    descOr: "Dhukkuba baakteeriyaa yaaluu kan gargaaru antibaayootikii bal'aa.",
    category: "antibiotics",
    price: 45,
    image: "💊",
    manufacturer: "Ethiopian Pharmaceuticals",
    dosageEn: "500mg every 8 hours for 7-10 days",
    dosageAm: "ለ7-10 ቀናት በ8 ሰዓት ልዩነት 500mg",
    sideEffectsEn: "Nausea, diarrhea, allergic reactions",
    sideEffectsAm: "ማቅለሽለሽ፣ ተቅማጥ፣ አለርጂ",
    requiresPrescription: true,
    inStock: true,
    rating: 4.8,
    reviews: 1240,
    emoji: "💊",
    color: "from-blue-500 to-blue-700",
  },
  {
    id: "2",
    nameEn: "Paracetamol 500mg",
    nameAm: "ፓራሲታሞል 500mg",
    nameOr: "Paracetamol 500mg",
    descEn: "Pain reliever and fever reducer. Effective for headaches, muscle aches, arthritis, backache, toothaches, colds, and fevers.",
    descAm: "የህመም ማስታገሻ እና ትኩሳት ቀናሽ። ለራስ ምታት፣ ጡንቻ ህመም፣ ጥርስ ህመም ውጤታማ።",
    descOr: "Dhukkuba qorichaa fi ho'a hir'isuu. Mataa dhukkuu, dhukkuba foonii fi ho'a irratti bu'a qabeessa.",
    category: "painRelief",
    price: 15,
    image: "🔴",
    manufacturer: "Addis Pharma",
    dosageEn: "500-1000mg every 4-6 hours, max 4g/day",
    dosageAm: "በ4-6 ሰዓት ልዩነት 500-1000mg፣ ከፍተኛ 4g/ቀን",
    sideEffectsEn: "Rare: liver damage with overdose",
    sideEffectsAm: "ብርቅ: ከልክ ያለፈ ሲወሰድ የጉበት ጉዳት",
    requiresPrescription: false,
    inStock: true,
    rating: 4.9,
    reviews: 3560,
    emoji: "🔴",
    color: "from-red-500 to-red-700",
  },
  {
    id: "3",
    nameEn: "Vitamin C 1000mg",
    nameAm: "ቫይታሚን ሲ 1000mg",
    nameOr: "Vitamin C 1000mg",
    descEn: "Essential vitamin for immune system support, collagen synthesis, and antioxidant protection.",
    descAm: "ለበሽታ መከላከያ ስርዓት፣ ኮላጅን ምርት እና አንቲኦክሲዳንት ጥበቃ አስፈላጊ ቫይታሚን።",
    descOr: "Vitaaminii sirna dhukkuba ittisuu, kolaajiinii fi antioksidaantii irratti barbaachisaa.",
    category: "vitamins",
    price: 120,
    image: "🟡",
    manufacturer: "NutriEthiopia",
    dosageEn: "1000mg once daily with food",
    dosageAm: "ከምግብ ጋር በቀን አንድ ጊዜ 1000mg",
    sideEffectsEn: "High doses may cause kidney stones",
    sideEffectsAm: "ከፍተኛ መጠን የኩላሊት ድንጋይ ሊያስከትል ይችላል",
    requiresPrescription: false,
    inStock: true,
    rating: 4.7,
    reviews: 890,
    emoji: "🟡",
    color: "from-yellow-400 to-orange-500",
  },
  {
    id: "4",
    nameEn: "Ambroxol Syrup",
    nameAm: "አምብሮክሶል ሲሮፕ",
    nameOr: "Ambroxol Siiraappii",
    descEn: "Mucolytic agent that helps loosen and clear mucus from airways. Used for cough and respiratory conditions.",
    descAm: "ከአየር መተላለፊያ ውስጥ ሙዝ ለማላቀቅ እና ለማጽዳት የሚረዳ። ለሳል እና የመተንፈሻ ሁኔታዎች ይጠቅማል።",
    descOr: "Mucus karuuruu fi qulqulleessuu gargaaru. Qufaa fi dhukkuba qilleensaa irratti gargaara.",
    category: "syrups",
    price: 85,
    image: "🍯",
    manufacturer: "Medtech Ethiopia",
    dosageEn: "10ml three times daily after meals",
    dosageAm: "ከምግብ በኋላ በቀን ሶስት ጊዜ 10ml",
    sideEffectsEn: "Nausea, vomiting, diarrhea",
    sideEffectsAm: "ማቅለሽለሽ፣ ማስታወክ፣ ተቅማጥ",
    requiresPrescription: false,
    inStock: true,
    rating: 4.6,
    reviews: 445,
    emoji: "🍯",
    color: "from-amber-400 to-amber-600",
  },
  {
    id: "5",
    nameEn: "Metformin 500mg",
    nameAm: "ሜትፎርሚን 500mg",
    nameOr: "Metformin 500mg",
    descEn: "First-line medication for type 2 diabetes. Helps control blood sugar levels.",
    descAm: "ለዓይነት 2 ስኳር ህመም የመጀመሪያ ደረጃ መድሃኒት። የደም ስኳር ደረጃን ለመቆጣጠር ይረዳል።",
    descOr: "Dhukkuba sukkaara gosa 2 irratti qoricha jalqabaa. Sukkaara dhiigaa to'achuu gargaara.",
    category: "antibiotics",
    price: 60,
    image: "⬜",
    manufacturer: "Ethiopian Pharmaceuticals",
    dosageEn: "500mg twice daily with meals",
    dosageAm: "ከምግብ ጋር በቀን ሁለት ጊዜ 500mg",
    sideEffectsEn: "Nausea, diarrhea, stomach upset",
    sideEffectsAm: "ማቅለሽለሽ፣ ተቅማጥ፣ የሆድ ምቾት ማጣት",
    requiresPrescription: true,
    inStock: true,
    rating: 4.5,
    reviews: 678,
    emoji: "⬜",
    color: "from-slate-400 to-slate-600",
  },
  {
    id: "6",
    nameEn: "ORS Sachets",
    nameAm: "ORS ሳሼቶች",
    nameOr: "ORS Saasheetota",
    descEn: "Oral Rehydration Salts for treating dehydration caused by diarrhea and vomiting.",
    descAm: "ተቅማጥ እና ማስታወክ ምክንያት ለሚፈጠር ድርቀት ለማከም የሚያገለግሉ የቃል ሪሃይድሬሽን ጨዎች።",
    descOr: "Dheebuu adeemsa kaasaa fi hanqaaquu irraa dhufu yaaluuf.",
    category: "syrups",
    price: 8,
    image: "🧂",
    manufacturer: "WHO Ethiopia",
    dosageEn: "1 sachet dissolved in 1L water",
    dosageAm: "1 ሳሼ በ1 ሊትር ውሃ ይቀልጡ",
    sideEffectsEn: "Generally safe, rare hypernatremia",
    sideEffectsAm: "ብዙ ጊዜ ደህና ነው",
    requiresPrescription: false,
    inStock: true,
    rating: 4.9,
    reviews: 2100,
    emoji: "🧂",
    color: "from-cyan-400 to-cyan-600",
  },
  {
    id: "7",
    nameEn: "Zinc Supplement",
    nameAm: "ዚንክ ሰፕሊሜንት",
    nameOr: "Zinc Suppleemantii",
    descEn: "Essential mineral for immune function, wound healing, and DNA synthesis.",
    descAm: "ለበሽታ መከላከያ ስርዓት፣ ቁስለት ፈውስ እና DNA ምርት አስፈላጊ ማዕድን።",
    descOr: "Sirna dhukkuba ittisuu, madaa fayyisuu fi DNA irratti barbaachisaa.",
    category: "vitamins",
    price: 95,
    image: "🔵",
    manufacturer: "NutriEthiopia",
    dosageEn: "20mg once daily",
    dosageAm: "በቀን አንድ ጊዜ 20mg",
    sideEffectsEn: "Nausea if taken on empty stomach",
    sideEffectsAm: "ሆድ ባዶ ሲሆን ማቅለሽለሽ",
    requiresPrescription: false,
    inStock: true,
    rating: 4.4,
    reviews: 320,
    emoji: "🔵",
    color: "from-blue-400 to-indigo-600",
  },
  {
    id: "8",
    nameEn: "Artemether-Lumefantrine",
    nameAm: "አርቴሜተር-ሉሜፋንትሪን",
    nameOr: "Artemether-Lumefantrine",
    descEn: "Combination antimalarial medication for treating uncomplicated malaria caused by Plasmodium falciparum.",
    descAm: "ፕላዝሞዲየም ፋልሲፓረም ምክንያት ለሚፈጠር ቀላል ወባ ለማከም የሚያገለግል ጥምር ፀረ-ወባ መድሃኒት።",
    descOr: "Busaa Plasmodium falciparum irraa dhufu yaaluuf qoricha busaa walitti makame.",
    category: "antibiotics",
    price: 180,
    image: "🟢",
    manufacturer: "Ethiopian Pharmaceuticals",
    dosageEn: "4 tablets twice daily for 3 days",
    dosageAm: "ለ3 ቀናት በቀን ሁለት ጊዜ 4 ኪኒን",
    sideEffectsEn: "Headache, dizziness, nausea",
    sideEffectsAm: "ራስ ምታት፣ ዝናብ፣ ማቅለሽለሽ",
    requiresPrescription: true,
    inStock: true,
    rating: 4.7,
    reviews: 890,
    emoji: "🟢",
    color: "from-green-500 to-emerald-700",
  },
];

export const providers: Provider[] = [
  {
    id: "p1",
    name: "Kenema Pharmacy",
    address: "Bole Road, Addis Ababa",
    distance: 0.8,
    rating: 4.9,
    isOpen: true,
    phone: "+251911234567",
    email: "kenema@pharmacy.et",
    telegram: "@kenema_pharma",
    github: "github.com/kenema-pharma",
    youtube: "youtube.com/@kenema",
    lat: 9.0054,
    lng: 38.7636,
    specialties: ["antibiotics", "vitamins", "painRelief"],
    color: "from-emerald-500 to-teal-600",
  },
  {
    id: "p2",
    name: "Addis Medicals",
    address: "Piazza, Addis Ababa",
    distance: 1.2,
    rating: 4.7,
    isOpen: true,
    phone: "+251922345678",
    email: "info@addismedicals.et",
    telegram: "@addis_medicals",
    github: "github.com/addis-medicals",
    youtube: "youtube.com/@addismedicals",
    lat: 9.0227,
    lng: 38.7468,
    specialties: ["syrups", "vaccines", "antibiotics"],
    color: "from-blue-500 to-indigo-600",
  },
  {
    id: "p3",
    name: "Hayat Pharmacy",
    address: "CMC, Addis Ababa",
    distance: 2.1,
    rating: 4.8,
    isOpen: false,
    phone: "+251933456789",
    email: "hayat@pharma.et",
    telegram: "@hayat_pharma",
    github: "github.com/hayat-pharma",
    youtube: "youtube.com/@hayatpharma",
    lat: 9.0392,
    lng: 38.7892,
    specialties: ["vitamins", "painRelief", "syrups"],
    color: "from-purple-500 to-violet-600",
  },
  {
    id: "p4",
    name: "Bethel Drug Store",
    address: "Megenagna, Addis Ababa",
    distance: 3.4,
    rating: 4.6,
    isOpen: true,
    phone: "+251944567890",
    email: "bethel@drugstore.et",
    telegram: "@bethel_drugs",
    github: "github.com/bethel-drugs",
    youtube: "youtube.com/@betheldrugs",
    lat: 9.0456,
    lng: 38.8012,
    specialties: ["antibiotics", "vaccines"],
    color: "from-rose-500 to-pink-600",
  },
];
