import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { t } from "../i18n";
import type { Language } from "../i18n";

export default function Header() {
  const { theme, toggleTheme, language, setLanguage } = useApp();
  const [showLang, setShowLang] = useState(false);

  const langs: { code: Language; label: string; flag: string }[] = [
    { code: "en", label: "English", flag: "🇬🇧" },
    { code: "am", label: "አማርኛ", flag: "🇪🇹" },
    { code: "or", label: "Afaan Oromoo", flag: "🇪🇹" },
  ];

  return (
    <header
      className={`sticky top-0 z-30 flex items-center justify-between px-4 py-3 ${
        theme === "dark"
          ? "bg-raey-dark/90 border-b border-raey-border"
          : "bg-white/90 border-b border-gray-100"
      }`}
      style={{ backdropFilter: "blur(20px)" }}
    >
      {/* Logo */}
      <div className="flex items-center gap-2">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary to-teal-400 flex items-center justify-center glow-green">
          <span className="text-lg">💊</span>
        </div>
        <div>
          <h1 className={`text-lg font-black leading-none ${theme === "dark" ? "text-white" : "text-gray-900"} glow-text-green`}>
            ራዕይ
          </h1>
          <p className="text-[10px] text-primary font-semibold leading-none">Ra'ey</p>
        </div>
      </div>

      {/* Right controls */}
      <div className="flex items-center gap-2">
        {/* Language selector */}
        <div className="relative">
          <button
            onClick={() => setShowLang(!showLang)}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              theme === "dark"
                ? "bg-white/10 text-white hover:bg-white/20"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            <span>{langs.find((l) => l.code === language)?.flag}</span>
            <span>{language.toUpperCase()}</span>
            <span className="text-[8px]">▼</span>
          </button>

          {showLang && (
            <div
              className={`absolute right-0 top-10 w-44 rounded-2xl shadow-2xl overflow-hidden z-50 ${
                theme === "dark" ? "bg-raey-card border border-raey-border" : "bg-white border border-gray-100"
              }`}
            >
              {langs.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => { setLanguage(lang.code); setShowLang(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium transition-all ${
                    language === lang.code
                      ? "bg-primary/20 text-primary"
                      : theme === "dark"
                      ? "text-white/80 hover:bg-white/10"
                      : "text-gray-700 hover:bg-gray-50"
                  }`}
                >
                  <span className="text-lg">{lang.flag}</span>
                  <span>{lang.label}</span>
                  {language === lang.code && <span className="ml-auto text-primary">✓</span>}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Theme toggle */}
        <button
          onClick={toggleTheme}
          className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
            theme === "dark"
              ? "bg-white/10 hover:bg-white/20 text-yellow-300"
              : "bg-gray-100 hover:bg-gray-200 text-gray-700"
          }`}
        >
          {theme === "dark" ? "☀️" : "🌙"}
        </button>

        {/* Notification bell */}
        <button
          className={`w-9 h-9 rounded-xl flex items-center justify-center relative transition-all ${
            theme === "dark" ? "bg-white/10 hover:bg-white/20" : "bg-gray-100 hover:bg-gray-200"
          }`}
        >
          <span className="text-lg">🔔</span>
          <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-red-500 animate-pulse" />
        </button>
      </div>
    </header>
  );
}
