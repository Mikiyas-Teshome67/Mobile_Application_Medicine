import React, { useEffect, useState } from "react";

interface Props {
  onDone: () => void;
}

export default function SplashScreen({ onDone }: Props) {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 500);
    const t2 = setTimeout(() => setPhase(2), 1500);
    const t3 = setTimeout(() => onDone(), 3000);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [onDone]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-raey-darker overflow-hidden">
      {/* Animated background rings */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-96 h-96 rounded-full border border-primary/10 animate-ping" style={{ animationDuration: "3s" }} />
        <div className="absolute w-72 h-72 rounded-full border border-primary/20 animate-ping" style={{ animationDuration: "2s" }} />
        <div className="absolute w-48 h-48 rounded-full border border-primary/30 animate-ping" style={{ animationDuration: "1.5s" }} />
      </div>

      {/* Floating particles */}
      {[...Array(12)].map((_, i) => (
        <div
          key={i}
          className="absolute w-1 h-1 rounded-full bg-primary/60"
          style={{
            left: `${10 + (i * 7.5)}%`,
            top: `${20 + Math.sin(i) * 30}%`,
            animation: `float ${2 + (i % 3)}s ease-in-out infinite`,
            animationDelay: `${i * 0.2}s`,
          }}
        />
      ))}

      {/* Logo */}
      <div
        className="relative z-10 flex flex-col items-center gap-4"
        style={{
          opacity: phase >= 1 ? 1 : 0,
          transform: phase >= 1 ? "scale(1) translateY(0)" : "scale(0.5) translateY(20px)",
          transition: "all 0.8s cubic-bezier(0.34, 1.56, 0.64, 1)",
        }}
      >
        {/* Icon */}
        <div className="relative">
          <div className="w-28 h-28 rounded-3xl bg-gradient-to-br from-primary to-teal-400 flex items-center justify-center shadow-glow-lg animate-glow-pulse">
            <span className="text-5xl">💊</span>
          </div>
          <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-gold-DEFAULT flex items-center justify-center glow-gold">
            <span className="text-sm">🇪🇹</span>
          </div>
        </div>

        {/* App name */}
        <div className="text-center">
          <h1 className="text-5xl font-black text-white glow-text-green tracking-tight">ራዕይ</h1>
          <p className="text-xl font-bold text-primary mt-1 tracking-widest">Ra'ey</p>
        </div>

        {/* Tagline */}
        <div
          className="text-center"
          style={{
            opacity: phase >= 2 ? 1 : 0,
            transform: phase >= 2 ? "translateY(0)" : "translateY(10px)",
            transition: "all 0.5s ease 0.2s",
          }}
        >
          <p className="text-white/60 text-sm font-medium">Ethiopia's #1 Medicine Delivery</p>
          <p className="text-primary/80 text-xs mt-1">Fast • Secure • Trusted</p>
        </div>
      </div>

      {/* Loading bar */}
      <div className="absolute bottom-16 w-48 h-1 bg-white/10 rounded-full overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-primary to-teal-400 rounded-full transition-all duration-2000"
          style={{ width: phase >= 2 ? "100%" : phase >= 1 ? "60%" : "20%", transition: "width 1s ease" }}
        />
      </div>

      <p className="absolute bottom-10 text-white/30 text-xs">Powered by ራዕይ Technology</p>
    </div>
  );
}
