import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { t } from "../i18n";
import type { Medicine, Provider } from "../data/medicines";

interface Props {
  medicine: Medicine;
  provider: Provider;
  onBack: () => void;
  onSuccess: () => void;
}

export default function PaymentScreen({ medicine, provider, onBack, onSuccess }: Props) {
  const { theme, language } = useApp();
  const isDark = theme === "dark";
  const [phone, setPhone] = useState("");
  const [step, setStep] = useState<"form" | "processing" | "success">("form");
  const [qty, setQty] = useState(1);

  const total = medicine.price * qty;

  const handlePay = () => {
    if (!phone || phone.length < 9) return;
    setStep("processing");
    setTimeout(() => setStep("success"), 2500);
  };

  const name = language === "am" ? medicine.nameAm : language === "or" ? medicine.nameOr : medicine.nameEn;

  if (step === "success") {
    return (
      <div className={`min-h-screen flex flex-col items-center justify-center px-6 ${isDark ? "bg-raey-darker" : "bg-gray-50"}`}>
        <div className="flex flex-col items-center gap-6 text-center">
          <div className="w-28 h-28 rounded-full bg-gradient-to-br from-primary to-teal-400 flex items-center justify-center glow-green animate-glow-pulse">
            <span className="text-5xl">✅</span>
          </div>
          <div>
            <h2 className={`text-2xl font-black ${isDark ? "text-white" : "text-gray-900"}`}>
              {t(language, "paymentSuccess")}
            </h2>
            <p className={`text-sm mt-2 ${isDark ? "text-white/60" : "text-gray-500"}`}>
              {name} • {total} {t(language, "birr")}
            </p>
            <p className={`text-xs mt-1 ${isDark ? "text-white/40" : "text-gray-400"}`}>
              {provider.name}
            </p>
          </div>
          <div className={`w-full rounded-3xl p-4 ${isDark ? "bg-raey-card border border-raey-border" : "bg-white shadow-card"}`}>
            <div className="flex items-center gap-3">
              <span className="text-3xl">🚚</span>
              <div className="text-left">
                <p className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{t(language, "trackOrder")}</p>
                <p className={`text-xs ${isDark ? "text-white/50" : "text-gray-500"}`}>Estimated: 30-45 min</p>
              </div>
              <div className="ml-auto w-3 h-3 rounded-full bg-primary animate-pulse" />
            </div>
          </div>
          <button
            onClick={onSuccess}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-primary to-teal-500 text-white font-black text-base"
          >
            {t(language, "back")}
          </button>
        </div>
      </div>
    );
  }

  if (step === "processing") {
    return (
      <div className={`min-h-screen flex flex-col items-center justify-center px-6 ${isDark ? "bg-raey-darker" : "bg-gray-50"}`}>
        <div className="flex flex-col items-center gap-6">
          <div className="w-24 h-24 rounded-full telebirr-btn flex items-center justify-center animate-glow-pulse">
            <span className="text-4xl">📱</span>
          </div>
          <p className={`text-lg font-bold ${isDark ? "text-white" : "text-gray-900"}`}>
            {t(language, "paymentProcessing")}
          </p>
          <div className="flex gap-2">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="w-3 h-3 rounded-full bg-primary animate-bounce"
                style={{ animationDelay: `${i * 0.2}s` }}
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen pb-24 ${isDark ? "bg-raey-darker" : "bg-gray-50"}`}>
      {/* Header */}
      <div className="telebirr-btn p-6 pt-12 relative overflow-hidden">
        <div className="absolute inset-0 shimmer" />
        <button
          onClick={onBack}
          className="absolute top-4 left-4 w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center text-white font-bold"
        >
          ←
        </button>
        <div className="relative z-10 flex flex-col items-center gap-2">
          <span className="text-5xl">📱</span>
          <h1 className="text-white text-xl font-black">{t(language, "payWithTelebirr")}</h1>
          <p className="text-white/70 text-sm">Secure • Fast • Trusted</p>
        </div>
      </div>

      <div className="px-4 mt-4 space-y-4">
        {/* Order summary */}
        <div className={`rounded-3xl p-4 ${isDark ? "bg-raey-card border border-raey-border" : "bg-white shadow-card"}`}>
          <h3 className={`text-sm font-bold mb-3 ${isDark ? "text-white/60" : "text-gray-500"}`}>ORDER SUMMARY</h3>
          <div className="flex items-center gap-3">
            <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${medicine.color} flex items-center justify-center`}>
              <span className="text-2xl">{medicine.emoji}</span>
            </div>
            <div className="flex-1">
              <p className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{name}</p>
              <p className={`text-xs ${isDark ? "text-white/50" : "text-gray-500"}`}>{provider.name}</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setQty(Math.max(1, qty - 1))}
                className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-white font-bold"
              >
                −
              </button>
              <span className={`text-base font-black w-6 text-center ${isDark ? "text-white" : "text-gray-900"}`}>{qty}</span>
              <button
                onClick={() => setQty(qty + 1)}
                className="w-8 h-8 rounded-xl bg-primary/20 flex items-center justify-center text-primary font-bold"
              >
                +
              </button>
            </div>
          </div>
          <div className={`mt-3 pt-3 border-t flex items-center justify-between ${isDark ? "border-raey-border" : "border-gray-100"}`}>
            <span className={`text-sm ${isDark ? "text-white/60" : "text-gray-500"}`}>{t(language, "total")}</span>
            <span className="text-primary font-black text-xl">{total} {t(language, "birr")}</span>
          </div>
        </div>

        {/* Phone input */}
        <div className={`rounded-3xl p-4 ${isDark ? "bg-raey-card border border-raey-border" : "bg-white shadow-card"}`}>
          <h3 className={`text-sm font-bold mb-3 ${isDark ? "text-white/60" : "text-gray-500"}`}>
            {t(language, "enterPhone").toUpperCase()}
          </h3>
          <div className={`flex items-center gap-3 px-4 py-3 rounded-2xl ${isDark ? "bg-white/5 border border-raey-border" : "bg-gray-50 border border-gray-200"}`}>
            <span className="text-xl">📱</span>
            <span className={`text-sm font-bold ${isDark ? "text-white/60" : "text-gray-500"}`}>+251</span>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 9))}
              placeholder="9XXXXXXXX"
              className={`flex-1 bg-transparent outline-none text-sm font-medium ${isDark ? "text-white placeholder-white/30" : "text-gray-800 placeholder-gray-400"}`}
            />
          </div>
        </div>

        {/* Pay button */}
        <button
          onClick={handlePay}
          disabled={phone.length < 9}
          className="w-full py-4 rounded-2xl telebirr-btn text-white font-black text-base disabled:opacity-40 disabled:cursor-not-allowed transition-all"
        >
          {t(language, "payNow")} • {total} {t(language, "birr")}
        </button>
      </div>
    </div>
  );
}
