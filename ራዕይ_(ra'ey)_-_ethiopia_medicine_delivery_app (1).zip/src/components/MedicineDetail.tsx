import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { t } from "../i18n";
import type { Medicine } from "../data/medicines";
import { providers } from "../data/medicines";
import PaymentScreen from "./PaymentScreen";

interface Props {
  medicine: Medicine;
  onBack: () => void;
}

export default function MedicineDetail({ medicine, onBack }: Props) {
  const { theme, language } = useApp();
  const [showPayment, setShowPayment] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState(providers[0]);
  const isDark = theme === "dark";

  const name = language === "am" ? medicine.nameAm : language === "or" ? medicine.nameOr : medicine.nameEn;
  const desc = language === "am" ? medicine.descAm : language === "or" ? medicine.descOr : medicine.descEn;
  const dosage = language === "am" ? medicine.dosageAm : medicine.dosageEn;
  const sideEffects = language === "am" ? medicine.sideEffectsAm : medicine.sideEffectsEn;

  if (showPayment) {
    return (
      <PaymentScreen
        medicine={medicine}
        provider={selectedProvider}
        onBack={() => setShowPayment(false)}
        onSuccess={() => setShowPayment(false)}
      />
    );
  }

  return (
    <div className={`min-h-screen pb-24 ${isDark ? "bg-raey-darker" : "bg-gray-50"}`}>
      {/* Hero */}
      <div className={`relative bg-gradient-to-br ${medicine.color} pt-12 pb-8 px-4`}>
        <button
          onClick={onBack}
          className="absolute top-4 left-4 w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center text-white font-bold text-lg"
        >
          ←
        </button>

        <div className="flex flex-col items-center gap-3">
          <div className="w-28 h-28 rounded-3xl bg-white/20 flex items-center justify-center animate-float">
            <span className="text-6xl">{medicine.emoji}</span>
          </div>
          <h1 className="text-white text-2xl font-black text-center">{name}</h1>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 bg-white/20 rounded-xl px-3 py-1">
              <span className="text-yellow-300 text-sm">⭐</span>
              <span className="text-white text-sm font-bold">{medicine.rating}</span>
              <span className="text-white/60 text-xs">({medicine.reviews})</span>
            </div>
            <div className={`rounded-xl px-3 py-1 ${medicine.requiresPrescription ? "bg-red-500/30" : "bg-green-500/30"}`}>
              <span className="text-white text-xs font-bold">
                {medicine.requiresPrescription ? `Rx` : t(language, "noPrescription")}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Price & Order */}
      <div className={`mx-4 -mt-4 rounded-3xl p-4 ${isDark ? "bg-raey-card border border-raey-border" : "bg-white shadow-card"}`}>
        <div className="flex items-center justify-between">
          <div>
            <span className="text-primary font-black text-3xl">{medicine.price}</span>
            <span className="text-primary/70 text-sm ml-1">{t(language, "birr")}</span>
          </div>
          <div className={`px-3 py-1.5 rounded-xl text-xs font-bold ${medicine.inStock ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`}>
            {medicine.inStock ? `✓ ${t(language, "inStock")}` : `✗ ${t(language, "outOfStock")}`}
          </div>
        </div>
        <button
          onClick={() => setShowPayment(true)}
          disabled={!medicine.inStock}
          className="w-full mt-4 py-3.5 rounded-2xl bg-gradient-to-r from-primary to-teal-500 text-white font-black text-base disabled:opacity-40"
        >
          {t(language, "orderNow")} 🛒
        </button>
      </div>

      {/* Details */}
      <div className="px-4 mt-4 space-y-3">
        {[
          { label: t(language, "description"), value: desc, icon: "📋" },
          { label: t(language, "dosage"), value: dosage, icon: "💉" },
          { label: t(language, "sideEffects"), value: sideEffects, icon: "⚠️" },
          { label: t(language, "manufacturer"), value: medicine.manufacturer, icon: "🏭" },
        ].map((item) => (
          <div key={item.label} className={`rounded-3xl p-4 ${isDark ? "bg-raey-card border border-raey-border" : "bg-white shadow-sm"}`}>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-lg">{item.icon}</span>
              <h3 className={`text-xs font-bold uppercase tracking-wider ${isDark ? "text-white/50" : "text-gray-400"}`}>{item.label}</h3>
            </div>
            <p className={`text-sm leading-relaxed ${isDark ? "text-white/80" : "text-gray-700"}`}>{item.value}</p>
          </div>
        ))}

        {/* Provider selection */}
        <div className={`rounded-3xl p-4 ${isDark ? "bg-raey-card border border-raey-border" : "bg-white shadow-sm"}`}>
          <h3 className={`text-xs font-bold uppercase tracking-wider mb-3 ${isDark ? "text-white/50" : "text-gray-400"}`}>
            📍 {t(language, "nearbyProviders")}
          </h3>
          <div className="space-y-2">
            {providers.map((p) => (
              <button
                key={p.id}
                onClick={() => setSelectedProvider(p)}
                className={`w-full flex items-center gap-3 p-3 rounded-2xl transition-all ${
                  selectedProvider.id === p.id
                    ? "bg-primary/20 border border-primary/40"
                    : isDark ? "bg-white/5 border border-transparent" : "bg-gray-50 border border-transparent"
                }`}
              >
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${p.color} flex items-center justify-center`}>
                  <span className="text-lg">🏥</span>
                </div>
                <div className="flex-1 text-left">
                  <p className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{p.name}</p>
                  <p className={`text-xs ${isDark ? "text-white/50" : "text-gray-500"}`}>{p.distance} {t(language, "km")}</p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${p.isOpen ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`}>
                    {p.isOpen ? t(language, "open") : t(language, "closed")}
                  </span>
                  {selectedProvider.id === p.id && <span className="text-primary text-xs">✓</span>}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
