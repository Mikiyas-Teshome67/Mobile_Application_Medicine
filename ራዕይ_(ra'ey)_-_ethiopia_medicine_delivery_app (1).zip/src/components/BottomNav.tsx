import React from "react";
import { useApp } from "../context/AppContext";
import { t } from "../i18n";
import type { NavTab } from "../context/AppContext";

const navItems: { id: NavTab; icon: string; activeIcon: string }[] = [
  { id: "explore", icon: "🔍", activeIcon: "🔍" },
  { id: "nearby", icon: "📍", activeIcon: "📍" },
  { id: "doctors", icon: "👨‍⚕️", activeIcon: "👨‍⚕️" },
  { id: "ai", icon: "🤖", activeIcon: "🤖" },
  { id: "profile", icon: "👤", activeIcon: "👤" },
];

const labelKeys: Record<NavTab, string> = {
  explore: "explore",
  nearby: "nearby",
  doctors: "doctors",
  ai: "aiAssist",
  profile: "profile",
};

const glowColors: Record<NavTab, string> = {
  explore: "rgba(16,185,129,0.6)",
  nearby: "rgba(59,130,246,0.6)",
  doctors: "rgba(139,92,246,0.6)",
  ai: "rgba(245,158,11,0.6)",
  profile: "rgba(236,72,153,0.6)",
};

const activeColors: Record<NavTab, string> = {
  explore: "text-emerald-400",
  nearby: "text-blue-400",
  doctors: "text-purple-400",
  ai: "text-amber-400",
  profile: "text-pink-400",
};

export default function BottomNav() {
  const { activeTab, setActiveTab, language, theme } = useApp();

  return (
    <nav
      className={`fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] z-40 bottom-nav ${
        theme === "dark"
          ? "bg-raey-dark/95 border-t border-raey-border"
          : "bg-white/95 border-t border-gray-200"
      }`}
      style={{ backdropFilter: "blur(20px)" }}
    >
      <div className="flex items-center justify-around px-2 py-2">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className="flex flex-col items-center gap-1 px-3 py-2 rounded-2xl transition-all duration-300 relative"
              style={
                isActive
                  ? {
                      background: `${glowColors[item.id].replace("0.6", "0.15")}`,
                      boxShadow: `0 0 16px ${glowColors[item.id]}`,
                    }
                  : {}
              }
            >
              {/* Active indicator dot */}
              {isActive && (
                <div
                  className="absolute -top-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full"
                  style={{ background: glowColors[item.id], boxShadow: `0 0 6px ${glowColors[item.id]}` }}
                />
              )}

              <span
                className="text-2xl transition-transform duration-300"
                style={{ transform: isActive ? "scale(1.2)" : "scale(1)" }}
              >
                {item.icon}
              </span>
              <span
                className={`text-[10px] font-semibold transition-all duration-300 ${
                  isActive
                    ? activeColors[item.id]
                    : theme === "dark"
                    ? "text-white/40"
                    : "text-gray-400"
                }`}
              >
                {t(language, labelKeys[item.id])}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
