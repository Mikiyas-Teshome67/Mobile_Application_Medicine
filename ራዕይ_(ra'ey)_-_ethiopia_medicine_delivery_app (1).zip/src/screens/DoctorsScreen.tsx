import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { t } from "../i18n";

const doctors = [
  {
    id: "d1",
    name: "Dr. Tigist Alemu",
    specialty: "General Practitioner",
    experience: "12 years",
    rating: 4.9,
    reviews: 340,
    available: true,
    emoji: "👩‍⚕️",
    color: "from-emerald-500 to-teal-600",
    fee: 150,
    languages: ["Amharic", "English"],
  },
  {
    id: "d2",
    name: "Dr. Bekele Haile",
    specialty: "Pediatrician",
    experience: "8 years",
    rating: 4.8,
    reviews: 210,
    available: true,
    emoji: "👨‍⚕️",
    color: "from-blue-500 to-indigo-600",
    fee: 200,
    languages: ["Amharic", "Oromoo", "English"],
  },
  {
    id: "d3",
    name: "Dr. Meron Tadesse",
    specialty: "Cardiologist",
    experience: "15 years",
    rating: 4.9,
    reviews: 520,
    available: false,
    emoji: "👩‍⚕️",
    color: "from-purple-500 to-violet-600",
    fee: 350,
    languages: ["Amharic", "English"],
  },
  {
    id: "d4",
    name: "Dr. Yonas Girma",
    specialty: "Dermatologist",
    experience: "6 years",
    rating: 4.7,
    reviews: 180,
    available: true,
    emoji: "👨‍⚕️",
    color: "from-rose-500 to-pink-600",
    fee: 250,
    languages: ["Amharic", "Oromoo"],
  },
];

export default function DoctorsScreen() {
  const { theme, language } = useApp();
  const isDark = theme === "dark";
  const [consulting, setConsulting] = useState<string | null>(null);

  return (
    <div className={`min-h-screen pb-24 ${isDark ? "bg-raey-darker" : "bg-gray-50"}`}>
      {/* Header banner */}
      <div className="relative overflow-hidden mx-4 mt-4 rounded-3xl">
        <div className="bg-gradient-to-br from-purple-600 via-violet-500 to-blue-600 p-6 relative">
          <div className="absolute inset-0 shimmer" />
          <div className="absolute top-0 right-0 w-32 h-32 rounded-full bg-white/10 blur-2xl" />
          <div className="relative z-10">
            <h2 className="text-white text-xl font-black">{t(language, "doctorsTitle")}</h2>
            <p className="text-white/70 text-sm mt-1">{t(language, "doctorsSubtitle")}</p>
            <div className="flex gap-3 mt-4">
              <div className="bg-white/20 rounded-2xl px-4 py-2 text-center">
                <p className="text-white font-black text-lg">50+</p>
                <p className="text-white/70 text-[10px]">Doctors</p>
              </div>
              <div className="bg-white/20 rounded-2xl px-4 py-2 text-center">
                <p className="text-white font-black text-lg">24/7</p>
                <p className="text-white/70 text-[10px]">Available</p>
              </div>
              <div className="bg-white/20 rounded-2xl px-4 py-2 text-center">
                <p className="text-white font-black text-lg">3</p>
                <p className="text-white/70 text-[10px]">Languages</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Doctor list */}
      <div className="px-4 mt-4 space-y-3">
        {doctors.map((doc, i) => (
          <div
            key={doc.id}
            className={`rounded-3xl overflow-hidden ${isDark ? "bg-raey-card border border-raey-border" : "bg-white border border-gray-100 shadow-sm"}`}
            style={{ animationDelay: `${i * 0.1}s` }}
          >
            <div className="flex items-center gap-4 p-4">
              <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${doc.color} flex items-center justify-center flex-shrink-0 relative`}>
                <span className="text-3xl">{doc.emoji}</span>
                <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 ${isDark ? "border-raey-card" : "border-white"} ${doc.available ? "bg-emerald-400" : "bg-gray-400"}`} />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{doc.name}</h4>
                <p className={`text-xs ${isDark ? "text-white/50" : "text-gray-500"}`}>{doc.specialty} • {doc.experience}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-yellow-400 text-xs">⭐</span>
                  <span className={`text-xs font-semibold ${isDark ? "text-white/70" : "text-gray-600"}`}>{doc.rating}</span>
                  <span className={`text-xs ${isDark ? "text-white/30" : "text-gray-400"}`}>({doc.reviews})</span>
                </div>
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {doc.languages.map((l) => (
                    <span key={l} className={`text-[9px] px-1.5 py-0.5 rounded-md font-semibold ${isDark ? "bg-white/10 text-white/60" : "bg-gray-100 text-gray-500"}`}>{l}</span>
                  ))}
                </div>
              </div>
              <div className="flex flex-col items-end gap-2">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${doc.available ? "bg-emerald-500/20 text-emerald-400" : "bg-gray-500/20 text-gray-400"}`}>
                  {doc.available ? t(language, "available") : t(language, "busy")}
                </span>
                <span className="text-primary font-black text-sm">{doc.fee} {t(language, "birr")}</span>
              </div>
            </div>

            {doc.available && (
              <div className="px-4 pb-4">
                {consulting === doc.id ? (
                  <div className={`rounded-2xl p-3 text-center ${isDark ? "bg-white/5" : "bg-gray-50"}`}>
                    <div className="flex items-center justify-center gap-2 mb-2">
                      <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                      <p className={`text-xs font-bold ${isDark ? "text-white/70" : "text-gray-600"}`}>Connecting to {doc.name}...</p>
                    </div>
                    <button
                      onClick={() => setConsulting(null)}
                      className="text-xs text-red-400 font-semibold"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setConsulting(doc.id)}
                    className={`w-full py-3 rounded-2xl bg-gradient-to-r ${doc.color} text-white font-bold text-sm`}
                  >
                    {t(language, "consultNow")} 💬
                  </button>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
