import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { t } from "../i18n";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import type { Language } from "../i18n";

export default function ProfileScreen() {
  const { theme, toggleTheme, language, setLanguage } = useApp();
  const isDark = theme === "dark";
  const user = useQuery(api.auth.loggedInUser);
  const [showLangPicker, setShowLangPicker] = useState(false);

  const langs: { code: Language; label: string; flag: string }[] = [
    { code: "en", label: "English", flag: "🇬🇧" },
    { code: "am", label: "አማርኛ", flag: "🇪🇹" },
    { code: "or", label: "Afaan Oromoo", flag: "🇪🇹" },
  ];

  const stats = [
    { label: t(language, "totalOrders"), value: "12", icon: "📦", color: "from-emerald-500 to-teal-600" },
    { label: t(language, "activeMeds"), value: "3", icon: "💊", color: "from-blue-500 to-indigo-600" },
    { label: t(language, "savedDoctors"), value: "5", icon: "👨‍⚕️", color: "from-purple-500 to-violet-600" },
    { label: t(language, "points"), value: "840", icon: "⭐", color: "from-amber-400 to-orange-500" },
  ];

  const menuItems = [
    { icon: "📦", label: t(language, "myOrders"), color: "text-emerald-400" },
    { icon: "📋", label: t(language, "myPrescriptions"), color: "text-blue-400" },
    { icon: "❤️", label: t(language, "savedMeds"), color: "text-red-400" },
    { icon: "🔔", label: t(language, "notifications"), color: "text-amber-400" },
    { icon: "🛡️", label: t(language, "healthCard"), color: "text-purple-400" },
    { icon: "⚙️", label: t(language, "settings"), color: "text-gray-400" },
  ];

  return (
    <div className={`min-h-screen pb-24 ${isDark ? "bg-raey-darker" : "bg-gray-50"}`}>
      {/* Profile hero */}
      <div className="bg-gradient-to-br from-pink-600 via-rose-500 to-orange-500 px-4 pt-6 pb-10 relative overflow-hidden">
        <div className="absolute inset-0 shimmer" />
        <div className="absolute top-0 right-0 w-32 h-32 rounded-full bg-white/10 blur-2xl" />
        <div className="relative z-10 flex items-center gap-4">
          <div className="relative">
            <div className="w-20 h-20 rounded-3xl bg-white/20 flex items-center justify-center text-4xl border-2 border-white/30">
              {user?.name ? user.name[0].toUpperCase() : "👤"}
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-primary flex items-center justify-center glow-green">
              <span className="text-[10px] text-white font-bold">✓</span>
            </div>
          </div>
          <div>
            <h2 className="text-white text-xl font-black">{user?.name ?? "Ra'ey User"}</h2>
            <p className="text-white/70 text-sm">{user?.email ?? "user@raey.et"}</p>
            <div className="flex items-center gap-1.5 mt-1">
              <span className="text-yellow-300 text-xs">⭐</span>
              <span className="text-white/80 text-xs font-semibold">Gold Member</span>
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="px-4 -mt-6 grid grid-cols-4 gap-2">
        {stats.map((s) => (
          <div key={s.label} className={`rounded-2xl p-3 text-center ${isDark ? "bg-raey-card border border-raey-border" : "bg-white shadow-sm"}`}>
            <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${s.color} flex items-center justify-center mx-auto mb-1`}>
              <span className="text-sm">{s.icon}</span>
            </div>
            <p className={`text-base font-black ${isDark ? "text-white" : "text-gray-900"}`}>{s.value}</p>
            <p className={`text-[9px] font-semibold leading-tight ${isDark ? "text-white/40" : "text-gray-400"}`}>{s.label}</p>
          </div>
        ))}
      </div>

      {/* Settings */}
      <div className="px-4 mt-4 space-y-3">
        {/* Theme toggle */}
        <div className={`rounded-3xl p-4 ${isDark ? "bg-raey-card border border-raey-border" : "bg-white shadow-sm"}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-2xl">{isDark ? "🌙" : "☀️"}</span>
              <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>
                {isDark ? t(language, "darkMode") : t(language, "lightMode")}
              </span>
            </div>
            <button
              onClick={toggleTheme}
              className={`w-12 h-6 rounded-full transition-all duration-300 relative ${isDark ? "bg-primary" : "bg-gray-200"}`}
            >
              <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all duration-300 ${isDark ? "left-6" : "left-0.5"}`} />
            </button>
          </div>
        </div>

        {/* Language */}
        <div className={`rounded-3xl overflow-hidden ${isDark ? "bg-raey-card border border-raey-border" : "bg-white shadow-sm"}`}>
          <button
            onClick={() => setShowLangPicker(!showLangPicker)}
            className="w-full flex items-center justify-between p-4"
          >
            <div className="flex items-center gap-3">
              <span className="text-2xl">🌐</span>
              <span className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{t(language, "language")}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className={`text-sm ${isDark ? "text-white/50" : "text-gray-500"}`}>
                {langs.find((l) => l.code === language)?.label}
              </span>
              <span className={`text-xs ${isDark ? "text-white/30" : "text-gray-400"}`}>{showLangPicker ? "▲" : "▼"}</span>
            </div>
          </button>
          {showLangPicker && (
            <div className={`border-t ${isDark ? "border-raey-border" : "border-gray-100"}`}>
              {langs.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => { setLanguage(lang.code); setShowLangPicker(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 text-sm transition-all ${
                    language === lang.code
                      ? "bg-primary/10 text-primary"
                      : isDark ? "text-white/70 hover:bg-white/5" : "text-gray-700 hover:bg-gray-50"
                  }`}
                >
                  <span className="text-lg">{lang.flag}</span>
                  <span className="font-medium">{lang.label}</span>
                  {language === lang.code && <span className="ml-auto text-primary">✓</span>}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Menu items */}
        <div className={`rounded-3xl overflow-hidden ${isDark ? "bg-raey-card border border-raey-border" : "bg-white shadow-sm"}`}>
          {menuItems.map((item, i) => (
            <button
              key={item.label}
              className={`w-full flex items-center gap-3 px-4 py-3.5 transition-all ${
                isDark ? "hover:bg-white/5" : "hover:bg-gray-50"
              } ${i > 0 ? `border-t ${isDark ? "border-raey-border" : "border-gray-50"}` : ""}`}
            >
              <span className={`text-xl ${item.color}`}>{item.icon}</span>
              <span className={`text-sm font-semibold flex-1 text-left ${isDark ? "text-white/80" : "text-gray-700"}`}>{item.label}</span>
              <span className={`text-xs ${isDark ? "text-white/20" : "text-gray-300"}`}>›</span>
            </button>
          ))}
        </div>

        {/* Developer card */}
        <div className={`rounded-3xl overflow-hidden ${isDark ? "bg-raey-card border border-raey-border" : "bg-white shadow-sm"}`}>
          <div className="bg-gradient-to-br from-primary via-teal-500 to-blue-600 p-4 relative overflow-hidden">
            <div className="absolute inset-0 shimmer" />
            <div className="relative z-10 flex items-center gap-3">
              <img
                src="https://avatars.githubusercontent.com/Mikiyas-Teshome67"
                alt="Mikiyas"
                className="w-12 h-12 rounded-2xl border-2 border-white/30 object-cover"
                onError={(e) => { (e.target as HTMLImageElement).src = "https://ui-avatars.com/api/?name=Mikiyas+Teshome&background=10B981&color=fff&size=48"; }}
              />
              <div>
                <p className="text-white font-black text-sm">{t(language, "devName")}</p>
                <p className="text-white/70 text-xs">{t(language, "devTitle")}</p>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-0">
            {[
              { icon: "🐙", label: "GitHub", url: "https://github.com/Mikiyas-Teshome67", color: "from-gray-600 to-gray-800" },
              { icon: "✈️", label: "Telegram", url: "https://t.me/mikiyas_teshome", color: "from-blue-500 to-blue-700" },
              { icon: "▶️", label: "YouTube", url: "https://youtube.com/@mikiyas", color: "from-red-500 to-red-700" },
            ].map((link) => (
              <a
                key={link.label}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className={`flex flex-col items-center gap-1 py-3 bg-gradient-to-br ${link.color} transition-all hover:opacity-90`}
              >
                <span className="text-xl">{link.icon}</span>
                <span className="text-white text-[10px] font-bold">{link.label}</span>
              </a>
            ))}
          </div>
        </div>

        {/* Ethiopia badge */}
        <div className={`rounded-3xl p-4 flex items-center justify-center gap-2 ${isDark ? "bg-raey-card border border-raey-border" : "bg-white shadow-sm"}`}>
          <span className="text-2xl">🇪🇹</span>
          <span className={`text-sm font-bold ${isDark ? "text-white/60" : "text-gray-500"}`}>Made with ❤️ for Ethiopia</span>
          <span className="text-2xl">🇪🇹</span>
        </div>
      </div>
    </div>
  );
}
