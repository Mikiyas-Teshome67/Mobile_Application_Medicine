import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { t } from "../i18n";
import { providers } from "../data/medicines";
import type { Provider } from "../data/medicines";

export default function NearbyScreen() {
  const { theme, language } = useApp();
  const isDark = theme === "dark";
  const [selected, setSelected] = useState<Provider | null>(null);

  if (selected) {
    return (
      <div className={`min-h-screen pb-24 ${isDark ? "bg-raey-darker" : "bg-gray-50"}`}>
        {/* Hero */}
        <div className={`relative bg-gradient-to-br ${selected.color} pt-12 pb-8 px-4`}>
          <button
            onClick={() => setSelected(null)}
            className="absolute top-4 left-4 w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center text-white font-bold text-lg"
          >
            ←
          </button>
          <div className="flex flex-col items-center gap-3">
            <div className="w-24 h-24 rounded-3xl bg-white/20 flex items-center justify-center animate-float">
              <span className="text-5xl">🏥</span>
            </div>
            <h1 className="text-white text-2xl font-black">{selected.name}</h1>
            <p className="text-white/70 text-sm">{selected.address}</p>
            <div className="flex items-center gap-2 bg-white/20 rounded-xl px-3 py-1">
              <span className="text-yellow-300">⭐</span>
              <span className="text-white font-bold text-sm">{selected.rating}</span>
              <span className={`text-xs font-bold ml-2 ${selected.isOpen ? "text-emerald-300" : "text-red-300"}`}>
                {selected.isOpen ? t(language, "open") : t(language, "closed")}
              </span>
            </div>
          </div>
        </div>

        <div className="px-4 mt-4 space-y-3">
          {/* Distance */}
          <div className={`rounded-3xl p-4 ${isDark ? "bg-raey-card border border-raey-border" : "bg-white shadow-sm"}`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-2xl">📍</span>
                <div>
                  <p className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>{selected.distance} {t(language, "km")}</p>
                  <p className={`text-xs ${isDark ? "text-white/50" : "text-gray-500"}`}>{selected.address}</p>
                </div>
              </div>
              <button className="px-4 py-2 rounded-xl bg-primary/20 text-primary text-xs font-bold">
                {t(language, "viewOnMap")}
              </button>
            </div>
          </div>

          {/* Contact */}
          <div className={`rounded-3xl p-4 ${isDark ? "bg-raey-card border border-raey-border" : "bg-white shadow-sm"}`}>
            <h3 className={`text-xs font-bold uppercase tracking-wider mb-3 ${isDark ? "text-white/50" : "text-gray-400"}`}>
              {t(language, "contactVia")}
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {[
                { icon: "📞", label: "Call", value: selected.phone, color: "from-green-500 to-emerald-600" },
                { icon: "✈️", label: "Telegram", value: selected.telegram, color: "from-blue-500 to-blue-700" },
                { icon: "📧", label: "Email", value: selected.email, color: "from-purple-500 to-violet-600" },
                { icon: "▶️", label: "YouTube", value: selected.youtube, color: "from-red-500 to-red-700" },
              ].map((c) => (
                <a
                  key={c.label}
                  href={c.label === "Call" ? `tel:${c.value}` : c.label === "Email" ? `mailto:${c.value}` : "#"}
                  className={`flex items-center gap-2 p-3 rounded-2xl bg-gradient-to-br ${c.color} transition-all hover:scale-105`}
                >
                  <span className="text-xl">{c.icon}</span>
                  <div>
                    <p className="text-white text-xs font-bold">{c.label}</p>
                    <p className="text-white/70 text-[10px] truncate max-w-[80px]">{c.value}</p>
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Specialties */}
          <div className={`rounded-3xl p-4 ${isDark ? "bg-raey-card border border-raey-border" : "bg-white shadow-sm"}`}>
            <h3 className={`text-xs font-bold uppercase tracking-wider mb-3 ${isDark ? "text-white/50" : "text-gray-400"}`}>
              Specialties
            </h3>
            <div className="flex flex-wrap gap-2">
              {selected.specialties.map((s) => (
                <span key={s} className="px-3 py-1.5 rounded-xl bg-primary/20 text-primary text-xs font-bold">
                  {t(language, s)}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen pb-24 ${isDark ? "bg-raey-darker" : "bg-gray-50"}`}>
      {/* Map placeholder */}
      <div className="mx-4 mt-4 rounded-3xl overflow-hidden map-container" style={{ height: 200 }}>
        <div className="map-grid w-full h-full relative flex items-center justify-center">
          <div className="absolute inset-0 flex items-center justify-center">
            {providers.map((p, i) => (
              <button
                key={p.id}
                onClick={() => setSelected(p)}
                className="absolute"
                style={{
                  left: `${20 + i * 20}%`,
                  top: `${30 + (i % 2) * 30}%`,
                }}
              >
                <div className="relative">
                  <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${p.color} flex items-center justify-center glow-green animate-pulse`}>
                    <span className="text-lg">🏥</span>
                  </div>
                  <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-primary rotate-45" />
                </div>
              </button>
            ))}
          </div>
          <div className="absolute top-3 left-3 bg-black/50 rounded-xl px-3 py-1.5">
            <p className="text-white text-xs font-bold">📍 Addis Ababa</p>
          </div>
        </div>
      </div>

      {/* Provider list */}
      <div className="px-4 mt-4">
        <h3 className={`text-base font-black mb-3 ${isDark ? "text-white" : "text-gray-900"}`}>
          {t(language, "nearbyProviders")}
        </h3>
        <div className="space-y-3">
          {providers.map((p, i) => (
            <button
              key={p.id}
              onClick={() => setSelected(p)}
              className={`w-full text-left rounded-3xl overflow-hidden transition-all duration-300 medicine-card ${
                isDark ? "bg-raey-card border border-raey-border" : "bg-white border border-gray-100 shadow-sm"
              }`}
              style={{ animationDelay: `${i * 0.1}s` }}
            >
              <div className="flex items-center gap-4 p-4">
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${p.color} flex items-center justify-center flex-shrink-0`}>
                  <span className="text-3xl">🏥</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className={`text-sm font-black ${isDark ? "text-white" : "text-gray-900"}`}>{p.name}</h4>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${p.isOpen ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`}>
                      {p.isOpen ? t(language, "open") : t(language, "closed")}
                    </span>
                  </div>
                  <p className={`text-xs mt-0.5 ${isDark ? "text-white/50" : "text-gray-500"}`}>{p.address}</p>
                  <div className="flex items-center gap-3 mt-2">
                    <div className="flex items-center gap-1">
                      <span className="text-yellow-400 text-xs">⭐</span>
                      <span className={`text-xs font-semibold ${isDark ? "text-white/70" : "text-gray-600"}`}>{p.rating}</span>
                    </div>
                    <span className={`text-xs ${isDark ? "text-white/40" : "text-gray-400"}`}>•</span>
                    <span className="text-primary text-xs font-semibold">{p.distance} {t(language, "km")}</span>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
