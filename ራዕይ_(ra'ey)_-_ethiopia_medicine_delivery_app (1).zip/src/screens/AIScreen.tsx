import React, { useState, useRef, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { t } from "../i18n";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  time: string;
}

const suggestions = [
  "What is Paracetamol used for?",
  "Side effects of Amoxicillin?",
  "How to take Metformin?",
  "Vitamin C dosage for adults?",
];

export default function AIScreen() {
  const { theme, language } = useApp();
  const isDark = theme === "dark";
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "0",
      role: "assistant",
      content: "Hello! I'm Ra'ey AI, your Ethiopian medical assistant. I can help you with medicine information, dosages, side effects, and general health questions. How can I help you today? 💊",
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const askAI = useMutation(api.ai.askMedicalQuestion);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const send = async (text?: string) => {
    const question = text ?? input.trim();
    if (!question || loading) return;
    setInput("");

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: question,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);

    try {
      const answer = await askAI({ question, language });
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: answer ?? "I'm sorry, I couldn't process that. Please try again.",
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: "Sorry, I encountered an error. Please try again.",
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`flex flex-col h-screen pb-16 ${isDark ? "bg-raey-darker" : "bg-gray-50"}`}>
      {/* Header */}
      <div className="bg-gradient-to-br from-amber-500 via-orange-500 to-red-500 px-4 pt-4 pb-6 relative overflow-hidden">
        <div className="absolute inset-0 shimmer" />
        <div className="relative z-10 flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center animate-float">
            <span className="text-2xl">🤖</span>
          </div>
          <div>
            <h2 className="text-white text-lg font-black">{t(language, "aiTitle")}</h2>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <p className="text-white/70 text-xs">{t(language, "aiSubtitle")}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            {msg.role === "assistant" && (
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center mr-2 flex-shrink-0 mt-1">
                <span className="text-sm">🤖</span>
              </div>
            )}
            <div className={`max-w-[80%] ${msg.role === "user" ? "items-end" : "items-start"} flex flex-col gap-1`}>
              <div
                className={`px-4 py-3 rounded-3xl text-sm leading-relaxed ${
                  msg.role === "user"
                    ? "bg-gradient-to-br from-primary to-teal-500 text-white rounded-br-lg"
                    : isDark
                    ? "bg-raey-card border border-raey-border text-white/90 rounded-bl-lg"
                    : "bg-white border border-gray-100 shadow-sm text-gray-800 rounded-bl-lg"
                }`}
              >
                {msg.content}
              </div>
              <span className={`text-[10px] px-1 ${isDark ? "text-white/30" : "text-gray-400"}`}>{msg.time}</span>
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center mr-2 flex-shrink-0">
              <span className="text-sm">🤖</span>
            </div>
            <div className={`px-4 py-3 rounded-3xl rounded-bl-lg ${isDark ? "bg-raey-card border border-raey-border" : "bg-white border border-gray-100 shadow-sm"}`}>
              <div className="flex gap-1.5 items-center">
                {[0, 1, 2].map((i) => (
                  <div key={i} className="w-2 h-2 rounded-full bg-amber-400 animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Suggestions */}
        {messages.length === 1 && !loading && (
          <div className="mt-4">
            <p className={`text-xs font-bold mb-2 ${isDark ? "text-white/40" : "text-gray-400"}`}>SUGGESTED QUESTIONS</p>
            <div className="flex flex-wrap gap-2">
              {suggestions.map((s) => (
                <button
                  key={s}
                  onClick={() => send(s)}
                  className={`text-xs px-3 py-2 rounded-2xl font-medium transition-all ${
                    isDark ? "bg-raey-card border border-raey-border text-white/70 hover:border-primary/50" : "bg-white border border-gray-200 text-gray-600 hover:border-primary/50"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className={`px-4 py-3 border-t ${isDark ? "bg-raey-dark border-raey-border" : "bg-white border-gray-100"}`}>
        <div className={`flex items-center gap-3 px-4 py-3 rounded-2xl ${isDark ? "bg-raey-card border border-raey-border" : "bg-gray-50 border border-gray-200"}`}>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder={t(language, "aiPlaceholder")}
            className={`flex-1 bg-transparent outline-none text-sm ${isDark ? "text-white placeholder-white/30" : "text-gray-800 placeholder-gray-400"}`}
          />
          <button
            onClick={() => send()}
            disabled={!input.trim() || loading}
            className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center disabled:opacity-40 transition-all"
          >
            <span className="text-white text-sm font-bold">↑</span>
          </button>
        </div>
      </div>
    </div>
  );
}
