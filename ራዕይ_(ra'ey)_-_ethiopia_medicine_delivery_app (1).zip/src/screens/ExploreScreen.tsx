import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { t } from "../i18n";
import { medicines } from "../data/medicines";
import type { Medicine } from "../data/medicines";
import MedicineDetail from "../components/MedicineDetail";

const categories = [
  { id: "all", icon: "🏥", color: "from-emerald-500 to-teal-600" },
  { id: "antibiotics", icon: "💊", color: "from-blue-500 to-indigo-600" },
  { id: "vitamins", icon: "🌟", color: "from-yellow-400 to-orange-500" },
  { id: "painRelief", icon: "🔴", color: "from-red-500 to-rose-600" },
  { id: "syrups", icon: "🍯", color: "from-amber-400 to-amber-600" },
  { id: "vaccines", icon: "💉", color: "from-purple-500 to-violet-600" },
];

export default function ExploreScreen() {
  const { theme, language } = useApp();
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [selectedMed, setSelectedMed] = useState<Medicine | null>(null);

  const filtered = medicines.filter((m) => {
    const matchCat = activeCategory === "all" || m.category === activeCategory;
    const name = language === "am" ? m.nameAm : language === "or" ? m.nameOr : m.nameEn;
    const matchSearch = name.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const isDark = theme === "dark";

  if (selectedMed) {
    return <MedicineDetail medicine={selectedMed} onBack={() => setSelectedMed(null)} />;
  }

  return (
    <div className={`min-h-screen pb-24 ${isDark ? "bg-raey-darker" : "bg-gray-50"}`}>
      {/* Hero Banner */}
      <div className="relative overflow-hidden mx-4 mt-4 rounded-3xl">
        <div className="bg-gradient-to-br from-primary via-teal-500 to-blue-600 p-6 relative">
          {/* Glow orbs */}
          <div className="absolute top-0 right-0 w-32 h-32 rounded-full bg-white/10 blur-2xl" />
          <div className="absolute bottom-0 left-0 w-24 h-24 rounded-full bg-teal-300/20 blur-xl" />

          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-white/80 text-sm">🇪🇹</span>
              <span className="text-white/80 text-xs font-medium">Ethiopia's Trusted Pharmacy</span>
            </div>
            <h2 className="text-white text-2xl font-black leading-tight">
              {t(language, "appTagline")}
            </h2>
            <p className="text-white/70 text-sm mt-1">{t(language, "appSubtag")}</p>

            <div className="flex gap-3 mt-4">
              <div className="bg-white/20 rounded-2xl px-4 py-2 text-center">
                <p className="text-white font-black text-lg">500+</p>
                <p className="text-white/70 text-[10px]">Medicines</p>
              </div>
              <div className="bg-white/20 rounded-2xl px-4 py-2 text-center">
                <p className="text-white font-black text-lg">50+</p>
                <p className="text-white/70 text-[10px]">Pharmacies</p>
              </div>
              <div className="bg-white/20 rounded-2xl px-4 py-2 text-center">
                <p className="text-white font-black text-lg">24/7</p>
                <p className="text-white/70 text-[10px]">Support</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="px-4 mt-4">
        <div className={`flex items-center gap-3 px-4 py-3 rounded-2xl ${
          isDark ? "bg-raey-card border border-raey-border" : "bg-white border border-gray-200 shadow-sm"
        }`}>
          <span className="text-xl">🔍</span>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t(language, "searchMedicine")}
            className={`flex-1 bg-transparent outline-none text-sm font-medium ${
              isDark ? "text-white placeholder-white/30" : "text-gray-800 placeholder-gray-400"
            }`}
          />
          {search && (
            <button onClick={() => setSearch("")} className="text-white/40 hover:text-white/80">✕</button>
          )}
        </div>
      </div>

      {/* Categories */}
      <div className="mt-5 px-4">
        <h3 className={`text-sm font-bold mb-3 ${isDark ? "text-white/60" : "text-gray-500"}`}>
          {t(language, "categories").toUpperCase()}
        </h3>
        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
          {categories.map((cat) => {
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`flex-shrink-0 flex flex-col items-center gap-1.5 px-4 py-3 rounded-2xl transition-all duration-300 ${
                  isActive
                    ? `bg-gradient-to-br ${cat.color} shadow-glow`
                    : isDark
                    ? "bg-raey-card border border-raey-border"
                    : "bg-white border border-gray-200"
                }`}
                style={isActive ? { boxShadow: "0 0 16px rgba(16,185,129,0.4)" } : {}}
              >
                <span className="text-2xl">{cat.icon}</span>
                <span className={`text-[10px] font-bold whitespace-nowrap ${
                  isActive ? "text-white" : isDark ? "text-white/60" : "text-gray-500"
                }`}>
                  {t(language, cat.id === "all" ? "allMeds" : cat.id)}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Featured medicines */}
      <div className="mt-6 px-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className={`text-base font-black ${isDark ? "text-white" : "text-gray-900"}`}>
            {t(language, "featured")}
          </h3>
          <span className={`text-xs font-semibold ${isDark ? "text-primary" : "text-primary"}`}>
            {filtered.length} items
          </span>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {filtered.map((med, i) => {
            const name = language === "am" ? med.nameAm : language === "or" ? med.nameOr : med.nameEn;
            const desc = language === "am" ? med.descAm : language === "or" ? med.descOr : med.descEn;
            return (
              <button
                key={med.id}
                onClick={() => setSelectedMed(med)}
                className={`medicine-card text-left rounded-3xl overflow-hidden transition-all duration-300 ${
                  isDark ? "bg-raey-card border border-raey-border" : "bg-white border border-gray-100 shadow-sm"
                }`}
                style={{
                  animationDelay: `${i * 0.1}s`,
                }}
              >
                {/* Card gradient top */}
                <div className={`bg-gradient-to-br ${med.color} p-4 flex items-center justify-center relative overflow-hidden`}>
                  <div className="absolute inset-0 shimmer" />
                  <span className="text-5xl relative z-10 animate-float" style={{ animationDelay: `${i * 0.3}s` }}>
                    {med.emoji}
                  </span>
                  {med.requiresPrescription && (
                    <div className="absolute top-2 right-2 bg-white/20 rounded-lg px-1.5 py-0.5">
                      <span className="text-[9px] text-white font-bold">Rx</span>
                    </div>
                  )}
                </div>

                {/* Card content */}
                <div className="p-3">
                  <h4 className={`text-sm font-bold leading-tight ${isDark ? "text-white" : "text-gray-900"}`}>
                    {name}
                  </h4>
                  <p className={`text-[11px] mt-1 line-clamp-2 ${isDark ? "text-white/50" : "text-gray-500"}`}>
                    {desc}
                  </p>

                  <div className="flex items-center justify-between mt-3">
                    <div>
                      <span className="text-primary font-black text-base">{med.price}</span>
                      <span className="text-primary/70 text-[10px] ml-1">{t(language, "birr")}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-yellow-400 text-xs">⭐</span>
                      <span className={`text-[11px] font-semibold ${isDark ? "text-white/70" : "text-gray-600"}`}>
                        {med.rating}
                      </span>
                    </div>
                  </div>

                  <div className={`mt-2 text-[10px] font-semibold ${med.inStock ? "text-emerald-400" : "text-red-400"}`}>
                    {med.inStock ? `✓ ${t(language, "inStock")}` : `✗ ${t(language, "outOfStock")}`}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Developer Section */}
      <div className="mt-10 mx-4 mb-6">
        <div className={`rounded-3xl overflow-hidden ${isDark ? "bg-raey-card border border-raey-border" : "bg-white border border-gray-100 shadow-sm"}`}>
          {/* Banner */}
          <div className="bg-gradient-to-br from-primary via-teal-500 to-blue-600 p-6 relative overflow-hidden">
            <div className="absolute inset-0 shimmer" />
            <div className="absolute top-0 right-0 w-24 h-24 rounded-full bg-white/10 blur-xl" />
            <p className={`text-white/70 text-xs font-semibold uppercase tracking-widest mb-2`}>
              {t(language, "developer")}
            </p>
            <h3 className="text-white text-xl font-black">{t(language, "devName")}</h3>
            <p className="text-white/80 text-sm">{t(language, "devTitle")}</p>
          </div>

          {/* Profile */}
          <div className="p-5">
            <div className="flex items-start gap-4">
              {/* GitHub profile picture */}
              <div className="relative flex-shrink-0">
                <img
                  src="https://avatars.githubusercontent.com/Mikiyas-Teshome67"
                  alt="Mikiyas Teshome"
                  className="w-20 h-20 rounded-2xl object-cover border-2 border-primary glow-green"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = "https://ui-avatars.com/api/?name=Mikiyas+Teshome&background=10B981&color=fff&size=80";
                  }}
                />
                <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-primary flex items-center justify-center glow-green">
                  <span className="text-[10px]">✓</span>
                </div>
              </div>

              <div className="flex-1">
                <p className={`text-sm leading-relaxed ${isDark ? "text-white/70" : "text-gray-600"}`}>
                  {t(language, "devBio")}
                </p>
              </div>
            </div>

            {/* Social links */}
            <div className="grid grid-cols-3 gap-2 mt-4">
              {[
                { icon: "🐙", label: "GitHub", url: "https://github.com/Mikiyas-Teshome67", color: "from-gray-600 to-gray-800" },
                { icon: "✈️", label: "Telegram", url: "https://t.me/mikiyas_teshome", color: "from-blue-500 to-blue-700" },
                { icon: "▶️", label: "YouTube", url: "https://youtube.com/@mikiyas", color: "from-red-500 to-red-700" },
              ].map((link) => (
                <a
                  key={link.label}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`flex flex-col items-center gap-1 py-3 rounded-2xl bg-gradient-to-br ${link.color} transition-all hover:scale-105`}
                  style={{ boxShadow: "0 4px 12px rgba(0,0,0,0.3)" }}
                >
                  <span className="text-xl">{link.icon}</span>
                  <span className="text-white text-[10px] font-bold">{link.label}</span>
                </a>
              ))}
            </div>

            {/* Ethiopia badge */}
            <div className={`mt-4 flex items-center justify-center gap-2 py-3 rounded-2xl ${
              isDark ? "bg-white/5" : "bg-gray-50"
            }`}>
              <span className="text-2xl">🇪🇹</span>
              <span className={`text-sm font-bold ${isDark ? "text-white/70" : "text-gray-600"}`}>
                Made with ❤️ for Ethiopia
              </span>
              <span className="text-2xl">🇪🇹</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
