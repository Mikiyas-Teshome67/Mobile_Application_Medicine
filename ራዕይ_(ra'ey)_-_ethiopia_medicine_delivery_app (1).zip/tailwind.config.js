const { fontFamily } = require("tailwindcss/defaultTheme");

module.exports = {
  mode: "jit",
  darkMode: "class",
  purge: ["./index.html", "./src/**/*.{vue,js,ts,jsx,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["Inter var", ...fontFamily.sans],
      },
      borderRadius: {
        DEFAULT: "8px",
        secondary: "4px",
        container: "12px",
        xl: "16px",
        "2xl": "20px",
        "3xl": "24px",
      },
      boxShadow: {
        DEFAULT: "0 1px 4px rgba(0, 0, 0, 0.1)",
        hover: "0 2px 8px rgba(0, 0, 0, 0.12)",
        glow: "0 0 20px rgba(16, 185, 129, 0.4)",
        "glow-lg": "0 0 40px rgba(16, 185, 129, 0.5)",
        "glow-blue": "0 0 20px rgba(59, 130, 246, 0.4)",
        "glow-purple": "0 0 20px rgba(139, 92, 246, 0.4)",
        "glow-gold": "0 0 20px rgba(245, 158, 11, 0.4)",
        "glow-red": "0 0 20px rgba(239, 68, 68, 0.4)",
        card: "0 4px 24px rgba(0,0,0,0.10)",
        "card-dark": "0 4px 24px rgba(0,0,0,0.40)",
      },
      colors: {
        primary: {
          DEFAULT: "#10B981",
          hover: "#059669",
          light: "#D1FAE5",
          dark: "#065F46",
        },
        secondary: {
          DEFAULT: "#6B7280",
          hover: "#4B5563",
        },
        accent: {
          DEFAULT: "#8B5CF6",
          hover: "#7C3AED",
        },
        gold: {
          DEFAULT: "#F59E0B",
          hover: "#D97706",
        },
        raey: {
          green: "#10B981",
          teal: "#0D9488",
          blue: "#3B82F6",
          purple: "#8B5CF6",
          gold: "#F59E0B",
          dark: "#0A0F1E",
          darker: "#060B14",
          card: "#111827",
          border: "#1F2937",
        },
      },
      spacing: {
        "form-field": "16px",
        section: "32px",
      },
      animation: {
        "glow-pulse": "glowPulse 2s ease-in-out infinite",
        "float": "float 3s ease-in-out infinite",
        "shimmer": "shimmer 2s linear infinite",
        "spin-slow": "spin 8s linear infinite",
        "bounce-slow": "bounce 3s infinite",
      },
      keyframes: {
        glowPulse: {
          "0%, 100%": { boxShadow: "0 0 20px rgba(16, 185, 129, 0.3)" },
          "50%": { boxShadow: "0 0 40px rgba(16, 185, 129, 0.7)" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-8px)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
      },
      backgroundImage: {
        "gradient-raey": "linear-gradient(135deg, #10B981 0%, #0D9488 50%, #3B82F6 100%)",
        "gradient-dark": "linear-gradient(135deg, #0A0F1E 0%, #060B14 100%)",
        "gradient-card": "linear-gradient(135deg, #111827 0%, #1F2937 100%)",
        "gradient-gold": "linear-gradient(135deg, #F59E0B 0%, #D97706 100%)",
        "shimmer-gradient": "linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.05) 50%, transparent 100%)",
      },
    },
  },
  variants: {
    extend: {
      boxShadow: ["hover", "active", "dark"],
    },
  },
};
