import { mutation } from "./_generated/server";
import { v } from "convex/values";
import OpenAI from "openai";

const openai = new OpenAI({
  baseURL: process.env.CONVEX_OPENAI_BASE_URL,
  apiKey: process.env.CONVEX_OPENAI_API_KEY,
});

export const askMedicalQuestion = mutation({
  args: {
    question: v.string(),
    language: v.string(),
  },
  handler: async (ctx, args) => {
    const systemPrompt = `You are Ra'ey AI, a helpful medical assistant for Ethiopia. You provide accurate, helpful information about medicines, dosages, side effects, and general health questions. Always recommend consulting a doctor for serious conditions. Keep responses concise and friendly. If the user writes in Amharic or Oromoo, respond in that language. Current language preference: ${args.language}.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4.1-nano",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: args.question },
      ],
      max_tokens: 400,
    });

    return response.choices[0].message.content;
  },
});
