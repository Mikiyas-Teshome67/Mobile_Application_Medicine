import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  diseases: defineTable({
    name: v.string(),
    description: v.string(),
    symptoms: v.array(v.string()),
    treatment: v.string(),
    prevention: v.string(),
    severity: v.string(), // "low", "medium", "high"
  }),
  
  detections: defineTable({
    userId: v.optional(v.id("users")),
    imageId: v.id("_storage"),
    prediction: v.string(),
    confidence: v.number(),
    isPlant: v.boolean(),
    timestamp: v.number(),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
