import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const seedDiseases = mutation({
  args: {},
  handler: async (ctx) => {
    // Check if diseases already exist
    const existing = await ctx.db.query("diseases").first();
    if (existing) return;

    const diseases = [
      {
        name: "Leaf Spot Disease",
        description: "A fungal infection causing circular spots on leaves",
        symptoms: ["Dark circular spots on leaves", "Yellow halos around spots", "Premature leaf drop"],
        treatment: "Apply copper-based fungicides every 7-14 days",
        prevention: "Ensure good air circulation, avoid overhead watering",
        severity: "medium"
      },
      {
        name: "Powdery Mildew",
        description: "White powdery fungal growth on leaf surfaces",
        symptoms: ["White powdery coating on leaves", "Yellowing leaves", "Stunted growth"],
        treatment: "Use sulfur-based fungicides or neem oil spray",
        prevention: "Maintain proper spacing between plants, reduce humidity",
        severity: "low"
      },
      {
        name: "Blight",
        description: "Rapid browning and death of plant tissues",
        symptoms: ["Brown or black lesions", "Rapid wilting", "Water-soaked spots"],
        treatment: "Remove affected parts immediately, apply copper fungicide",
        prevention: "Avoid overhead watering, ensure good drainage",
        severity: "high"
      },
      {
        name: "Rust Disease",
        description: "Orange or reddish pustules on leaf undersides",
        symptoms: ["Orange/red pustules on leaves", "Yellow spots on upper leaf surface", "Leaf distortion"],
        treatment: "Apply systemic fungicides containing propiconazole",
        prevention: "Remove infected debris, improve air circulation",
        severity: "medium"
      },
      {
        name: "Healthy Leaf",
        description: "No disease detected - plant appears healthy",
        symptoms: ["Green, vibrant foliage", "No spots or discoloration", "Normal growth pattern"],
        treatment: "Continue regular care and monitoring",
        prevention: "Maintain good cultural practices",
        severity: "low"
      }
    ];

    for (const disease of diseases) {
      await ctx.db.insert("diseases", disease);
    }
  },
});

export const getDiseaseInfo = query({
  args: { name: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("diseases")
      .filter((q) => q.eq(q.field("name"), args.name))
      .first();
  },
});

export const getAllDiseases = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("diseases").collect();
  },
});
