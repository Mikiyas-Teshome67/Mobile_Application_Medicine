import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

export const saveDetection = mutation({
  args: {
    imageId: v.id("_storage"),
    prediction: v.string(),
    confidence: v.number(),
    isPlant: v.boolean(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    
    await ctx.db.insert("detections", {
      userId: userId || undefined,
      imageId: args.imageId,
      prediction: args.prediction,
      confidence: args.confidence,
      isPlant: args.isPlant,
      timestamp: Date.now(),
    });
  },
});

export const getRecentDetections = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const detections = await ctx.db
      .query("detections")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(10);

    return Promise.all(
      detections.map(async (detection) => ({
        ...detection,
        imageUrl: await ctx.storage.getUrl(detection.imageId),
      }))
    );
  },
});
