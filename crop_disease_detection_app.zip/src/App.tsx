import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { CropDetector } from "./CropDetector";
import { DetectionHistory } from "./DetectionHistory";
import { useEffect } from "react";
import { useMutation } from "convex/react";

export default function App() {
  const seedDiseases = useMutation(api.diseases.seedDiseases);

  useEffect(() => {
    seedDiseases();
  }, [seedDiseases]);

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-green-50 to-emerald-100">
      <header className="sticky top-0 z-10 bg-white/90 backdrop-blur-sm border-b shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold">🌱</span>
            </div>
            <h1 className="text-2xl font-bold text-green-800">CropCare AI</h1>
          </div>
          <Authenticated>
            <SignOutButton />
          </Authenticated>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        <Authenticated>
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-4xl font-bold text-green-800 mb-4">
                AI-Powered Crop Disease Detection
              </h2>
              <p className="text-lg text-green-600 max-w-2xl mx-auto">
                Upload a photo of your crop leaves and get instant disease diagnosis 
                with treatment recommendations powered by advanced AI.
              </p>
            </div>
            
            <div className="grid lg:grid-cols-2 gap-8">
              <CropDetector />
              <DetectionHistory />
            </div>
          </div>
        </Authenticated>

        <Unauthenticated>
          <div className="max-w-md mx-auto">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🌱</span>
              </div>
              <h2 className="text-3xl font-bold text-green-800 mb-4">Welcome to CropCare AI</h2>
              <p className="text-green-600">
                Sign in to start detecting crop diseases with AI-powered analysis
              </p>
            </div>
            <SignInForm />
          </div>
        </Unauthenticated>
      </main>

      <Toaster />
    </div>
  );
}
