import { useQuery } from "convex/react";
import { api } from "../convex/_generated/api";

export function DetectionHistory() {
  const detections = useQuery(api.detection.getRecentDetections);

  if (!detections) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
          <span className="text-2xl">📊</span>
          Detection History
        </h3>
        <div className="flex justify-center items-center h-32">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h3 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
        <span className="text-2xl">📊</span>
        Detection History
      </h3>

      {detections.length === 0 ? (
        <div className="text-center py-8">
          <span className="text-6xl mb-4 block">🔍</span>
          <p className="text-gray-500">No detections yet</p>
          <p className="text-sm text-gray-400 mt-1">
            Upload your first crop image to get started
          </p>
        </div>
      ) : (
        <div className="space-y-4 max-h-96 overflow-y-auto">
          {detections.map((detection) => (
            <div
              key={detection._id}
              className="border rounded-lg p-4 hover:bg-gray-50 transition-colors"
            >
              <div className="flex gap-4">
                {detection.imageUrl && (
                  <img
                    src={detection.imageUrl}
                    alt="Detection"
                    className="w-16 h-16 object-cover rounded-lg flex-shrink-0"
                  />
                )}
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className={`font-semibold ${
                        detection.isPlant ? 'text-gray-800' : 'text-red-600'
                      }`}>
                        {detection.prediction}
                      </h4>
                      <p className="text-sm text-gray-500">
                        Confidence: {detection.confidence.toFixed(1)}%
                      </p>
                    </div>
                    
                    <div className="text-right">
                      <p className="text-xs text-gray-400">
                        {new Date(detection.timestamp).toLocaleDateString()}
                      </p>
                      <p className="text-xs text-gray-400">
                        {new Date(detection.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                  
                  {!detection.isPlant && (
                    <p className="text-xs text-red-500 mt-1">
                      ⚠️ Not a plant image
                    </p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
