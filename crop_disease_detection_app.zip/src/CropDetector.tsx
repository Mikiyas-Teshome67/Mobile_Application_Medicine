import { useState, useRef } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";

const CLASS_NAMES = [
  "Leaf Spot Disease",
  "Powdery Mildew", 
  "Blight",
  "Rust Disease",
  "Healthy Leaf"
];

export function CropDetector() {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<{
    prediction: string;
    confidence: number;
    isPlant: boolean;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  const generateUploadUrl = useMutation(api.detection.generateUploadUrl);
  const saveDetection = useMutation(api.detection.saveDetection);
  const getDiseaseInfo = useQuery(
    api.diseases.getDiseaseInfo,
    result ? { name: result.prediction } : "skip"
  );

  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error("Please select a valid image file");
      return;
    }

    setSelectedImage(file);
    setResult(null);

    const reader = new FileReader();
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const isPlantImage = (imageElement: HTMLImageElement): boolean => {
    // Simple heuristic: check if image has green pixels
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return false;

    canvas.width = imageElement.width;
    canvas.height = imageElement.height;
    ctx.drawImage(imageElement, 0, 0);

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    
    let greenPixels = 0;
    let totalPixels = 0;

    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      
      // Check if pixel is greenish (plant-like)
      if (g > r && g > b && g > 50) {
        greenPixels++;
      }
      totalPixels++;
    }

    const greenRatio = greenPixels / totalPixels;
    return greenRatio > 0.1; // At least 10% green pixels
  };

  const simulateAIDetection = (imageElement: HTMLImageElement) => {
    const isPlant = isPlantImage(imageElement);
    
    if (!isPlant) {
      return {
        prediction: "Not a Plant",
        confidence: 95 + Math.random() * 5,
        isPlant: false
      };
    }

    // Simulate AI prediction with random but realistic results
    const randomIndex = Math.floor(Math.random() * CLASS_NAMES.length);
    const baseConfidence = 60 + Math.random() * 35; // 60-95%
    
    return {
      prediction: CLASS_NAMES[randomIndex],
      confidence: Math.round(baseConfidence * 100) / 100,
      isPlant: true
    };
  };

  const handleDetection = async () => {
    if (!selectedImage || !imageRef.current) {
      toast.error("Please select an image first");
      return;
    }

    setIsAnalyzing(true);

    try {
      // Simulate AI processing delay
      await new Promise(resolve => setTimeout(resolve, 2000));

      const detectionResult = simulateAIDetection(imageRef.current);
      setResult(detectionResult);

      // Upload image and save detection
      const uploadUrl = await generateUploadUrl();
      const uploadResponse = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": selectedImage.type },
        body: selectedImage,
      });

      if (!uploadResponse.ok) {
        throw new Error("Failed to upload image");
      }

      const { storageId } = await uploadResponse.json();

      await saveDetection({
        imageId: storageId,
        prediction: detectionResult.prediction,
        confidence: detectionResult.confidence,
        isPlant: detectionResult.isPlant,
      });

      if (!detectionResult.isPlant) {
        toast.error("This doesn't appear to be a plant image. Please upload a clear photo of crop leaves.");
      } else if (detectionResult.confidence < 70) {
        toast.warning("Low confidence detection. Consider uploading a clearer image.");
      } else {
        toast.success("Disease detection completed successfully!");
      }

    } catch (error) {
      console.error("Detection failed:", error);
      toast.error("Detection failed. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return "text-green-600";
    if (confidence >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  const getConfidenceDescription = (confidence: number, isPlant: boolean) => {
    if (!isPlant) {
      return "The uploaded image does not appear to be a plant. Please upload a clear photo of crop leaves for accurate disease detection.";
    }

    if (confidence >= 85) {
      return "High confidence detection. The AI is very certain about this diagnosis.";
    } else if (confidence >= 70) {
      return "Good confidence detection. The diagnosis is likely accurate.";
    } else if (confidence >= 50) {
      return "Moderate confidence. Consider uploading a clearer image or consulting an expert.";
    } else {
      return "Low confidence detection. Please upload a clearer, well-lit image of the leaf.";
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h3 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
        <span className="text-2xl">📸</span>
        Disease Detection
      </h3>

      <div className="space-y-6">
        {/* Image Upload */}
        <div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageSelect}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full p-4 border-2 border-dashed border-green-300 rounded-lg hover:border-green-400 transition-colors"
          >
            <div className="text-center">
              <span className="text-4xl mb-2 block">📷</span>
              <p className="text-green-600 font-medium">
                {selectedImage ? "Change Image" : "Upload Crop Image"}
              </p>
              <p className="text-sm text-gray-500 mt-1">
                JPG, PNG, or WEBP (max 10MB)
              </p>
            </div>
          </button>
        </div>

        {/* Image Preview */}
        {imagePreview && (
          <div className="bg-gray-50 rounded-lg p-4">
            <img
              ref={imageRef}
              src={imagePreview}
              alt="Selected crop"
              className="w-full h-64 object-contain rounded-lg"
            />
          </div>
        )}

        {/* Detect Button */}
        <button
          onClick={handleDetection}
          disabled={!selectedImage || isAnalyzing}
          className="w-full bg-green-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {isAnalyzing ? (
            <div className="flex items-center justify-center gap-2">
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              Analyzing Image...
            </div>
          ) : (
            "🔍 Detect Disease"
          )}
        </button>

        {/* Results */}
        {result && (
          <div className="bg-gray-50 rounded-lg p-6 space-y-4">
            <div className="text-center">
              <h4 className="text-xl font-bold text-gray-800 mb-2">Detection Result</h4>
              
              {result.isPlant ? (
                <div className="space-y-2">
                  <p className="text-2xl font-bold text-green-800">{result.prediction}</p>
                  <p className={`text-lg font-semibold ${getConfidenceColor(result.confidence)}`}>
                    Confidence: {result.confidence.toFixed(1)}%
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="text-2xl font-bold text-red-600">❌ Not a Plant Image</p>
                  <p className="text-lg font-semibold text-red-600">
                    Confidence: {result.confidence.toFixed(1)}%
                  </p>
                </div>
              )}
              
              <p className="text-sm text-gray-600 mt-3">
                {getConfidenceDescription(result.confidence, result.isPlant)}
              </p>
            </div>

            {/* Disease Information */}
            {result.isPlant && getDiseaseInfo && (
              <div className="border-t pt-4 space-y-3">
                <div>
                  <h5 className="font-semibold text-gray-800 mb-1">Description:</h5>
                  <p className="text-gray-600 text-sm">{getDiseaseInfo.description}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-gray-800 mb-1">Symptoms:</h5>
                  <ul className="text-gray-600 text-sm space-y-1">
                    {getDiseaseInfo.symptoms.map((symptom, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="text-green-600 mt-1">•</span>
                        {symptom}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h5 className="font-semibold text-gray-800 mb-1">Treatment:</h5>
                  <p className="text-gray-600 text-sm">{getDiseaseInfo.treatment}</p>
                </div>

                <div>
                  <h5 className="font-semibold text-gray-800 mb-1">Prevention:</h5>
                  <p className="text-gray-600 text-sm">{getDiseaseInfo.prevention}</p>
                </div>

                <div className="flex items-center gap-2">
                  <span className="font-semibold text-gray-800">Severity:</span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    getDiseaseInfo.severity === 'high' ? 'bg-red-100 text-red-800' :
                    getDiseaseInfo.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {getDiseaseInfo.severity.toUpperCase()}
                  </span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
